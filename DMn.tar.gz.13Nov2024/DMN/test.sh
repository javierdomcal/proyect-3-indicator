#!/bin/bash 
######!/bin/bash -x

Cln=/bin/rm
#Prog="mpirun -n 2 ../DMNp"
Prog="../DMN"

$Cln -rf test_new
mkdir test_new
#
cp test/test*inp test_new/
cp test/test*sh  test_new/
cp test/test8.fchk  test_new/
#
cd test_new
#
for ((i=1;i<=6;i++)); do
   echo ' ---------------------- Doing test'$i '-----------------------------'
   $Prog test$i.inp > test$i.out
   sort -n test$i.out > test$i.out-sorted
   sort -n ../test/test$i.out > test$i.out-sorted2
   diff -b test$i.out-sorted test$i.out-sorted2
   $Cln test$i.out-sorted test$i.out-sorted2
   #grep -Fxv -f ../test/test$i.out test$i.out
   #if [ $i -eq 2 ] || [ $i -eq 6 ] || [ $i -eq 3 ]; then
   #  ../READGAM test${i}_gam.sbf
   #  mv fort.88 test${i}_for.gam
   #  diff -b ../test/test${i}_for.gam test${i}_for.gam 
   #fi
done
# Test 6
../UNFOR test6.dm1 1 8 >& /dev/null
mv fort.88 test6_for.dm1
../UNFOR test6.dm2 2 8 >& /dev/null
mv fort.88 test6_for.dm2
diff -b test6_for.dm1 ../test/test6_for.dm1
diff -b test6_for.dm2 ../test/test6_for.dm2
# Test 7
i=7
echo ' ---------------------- Doing test'$i '-----------------------------'
$Prog test$i.inp > test$i.out
diff -b ../test/test$i.out test$i.out
# Test 8
i=8
echo ' ---------------------- Doing test'$i '-----------------------------'
./test8.sh
diff -b ../test/test8.out test8.out
diff -b ../test/test8_cs.out test8_cs.out
# Test 9
i=9
echo ' ---------------------- Doing test'$i '-----------------------------'
$Prog test$i.inp > test$i.out
diff -b ../test/test$i.out test$i.out
# Test 10
i=10
echo ' ---------------------- Doing test'$i '-----------------------------'
# Same as test1 but tests DM3APPROX, DM3 and cumulant
$Prog test$i.inp > test$i.out
for approx in vald mazz naka; do
  ../UNFOR $approx.dm3 3 8 >& /dev/null
  sort -n ../test/test${i}_for.3$approx > ../test/test${i}_sfor.3$approx
  sort -n fort.88 > test${i}_sfor.3$approx
  $Cln fort.88
  diff -b ../test/test${i}_sfor.3$approx test${i}_sfor.3$approx
done
../UNFOR test$i.dm3 3 8 >& /dev/null
sort -n ../test/test${i}_for.dm3 > ../test/test${i}_sfor.dm3
sort -n fort.88 > test${i}_sfor.dm3
$Cln fort.88
diff -b ../test/test${i}_sfor.dm3 test${i}_sfor.dm3
../UNFOR cumul.dm2 2 8 >& /dev/null
mv fort.88 test${i}_for.2cum
diff -b ../test/test${i}_for.2cum test${i}_for.2cum
# Test 13
i=13
echo ' ---------------------- Doing test'$i '-----------------------------'
# Same as test1 but Spinless
$Prog test$i.inp > test$i.out
sort -n test$i.out > test$i.out-sorted
sort -n ../test/test$i.out > test$i.out-sorted2
diff -b test$i.out-sorted test$i.out-sorted2
$Cln test$i.out-sorted test$i.out-sorted2
../UNFOR test$i.sdm2 2 8 >& /dev/null
sort -n ../test/test${i}_for.sdm2 > ../test/test${i}_sfor.sdm2
sort -n fort.88 > test${i}_sfor.sdm2
$Cln fort.88
diff -b ../test/test${i}_sfor.sdm2 test${i}_sfor.sdm2
