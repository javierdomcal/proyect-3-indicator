#ifdef MPI
!
! MPI MODULE
!
  INCLUDE 'mpif.h'
  INTEGER STATUS(MPI_STATUS_SIZE)
  INTEGER MY_ID, NPROCS, IERR, MASTER
  LOGICAL LMASTR
  PARAMETER (MASTER=0)
  COMMON /MPIM/ STATUS,MY_ID,NPROCS,IERR,LMASTR
#else
!
!     SERIAL MODULE
!
  LOGICAL LMASTR
  INTEGER NPROCS,MASTER,MY_ID
  COMMON /SERIAL/ MY_ID,NPROCS,LMASTR
  PARAMETER (MASTER=1)
#endif
!
!     COMMON MODULE
!
  Integer*8 NCores,MCores
  Common /Parallel/ NCores
!
!     Distribution of cores among processes
!     NCores -> Parallelization Determinants
!
