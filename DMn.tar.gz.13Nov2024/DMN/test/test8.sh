#/bin/bash

# Test for DM2 with its use in corrspin program
# by Istvan Mayer (calculation of S^2 decomp).

cs=../../corrspin/corrspin
RM=/bin/rm

../DMN test8.inp > test8.out
../UNFOR test8.dm1 1 >& /dev/null
mv fort.88 test8_for.dm1
../UNFOR test8.dm2 2 >& /dev/null
mv fort.88 test8_for.dm2
cat << eor > test8.in
test8.fchk
test8_for.dm1
test8_for.dm2
eor
$cs < test8.in > test8_cs.out
$RM test8.in Tmp
